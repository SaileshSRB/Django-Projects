# Clinic Booking Project
 A Django booking project for a health clinic.

#### My Project's Article In Medium.com: [Link](https://medium.com/dev-genius/django-tutorial-on-how-to-create-a-booking-system-for-a-health-clinic-9b1920fc2b78)