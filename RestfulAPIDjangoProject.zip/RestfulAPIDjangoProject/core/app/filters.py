from .models import Workout
from django_filters.rest_framework import FilterSet

class WorkoutFilter(FilterSet):
    class Meta:
        model=Workout
        fields= {
            'activity__name':['exact'],
        }