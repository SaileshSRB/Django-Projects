from django.urls import path,include
from . import views
from rest_framework_nested import routers
from .models import Workout
from django_filters.rest_framework import DjangoFilterBackend
from .filters import WorkoutFilter

router=routers.SimpleRouter()
router.register('workouts',views.WorkoutViewSet,basename='workout')
router.register('gyms',views.GymViewSet)
workouts_router=routers.NestedSimpleRouter(router,'gyms',lookup='gym')
workouts_router.register('workouts',views.WorkoutViewSet,basename='gym-workouts')
urlpatterns=router.urls + workouts_router.urls


