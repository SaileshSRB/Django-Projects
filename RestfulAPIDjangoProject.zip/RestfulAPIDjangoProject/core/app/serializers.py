from rest_framework import serializers

from .models import Gym,Workout,Activity,Profile

class GymSerializerGet(serializers.ModelSerializer):
    class Meta:
        model=Gym
        fields=['id','name']
    # id=serializers.IntegerField()
    # name=serializers.CharField(max_length=255)
class GymSerializerPost(serializers.ModelSerializer):
    class Meta:
        model=Gym
        fields= ['name','description','address','phone']

class ActivityForWorkoutSerializer(serializers.ModelSerializer):
    class Meta:
        model=Activity
        fields=['name']

class ProfileForWorkoutSerializer(serializers.ModelSerializer):
    class Meta:
        model=Profile
        fields=['first_name','last_name','phone','email','status']

class WorkoutSerializerRead(serializers.ModelSerializer):
    class Meta:
        model=Workout
        fields=['id','time','gym','activity','profile']
    gym=GymSerializerGet()
    activity=ActivityForWorkoutSerializer()
    profile=ProfileForWorkoutSerializer(many=True)

class WorkoutSerializerWrite(serializers.ModelSerializer):
    class Meta:
        model=Workout
        fields=['id','time','gym','activity','profile']
    gym=serializers.PrimaryKeyRelatedField(queryset=Gym.objects.all())
    activity=serializers.PrimaryKeyRelatedField(queryset=Activity.objects.all())
    profile=serializers.PrimaryKeyRelatedField(queryset=Profile.objects.all(),many=True)






