console.log('test static files');
