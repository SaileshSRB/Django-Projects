# Gym-Management-System

To create a Gym management system to record the attendance, register new members to the gym, check
payment status, view the total revenue of the gym etc. and also to check the Gym status using face
recognition Software
Front end - Html CSS
Back end - Django Python OpenCV

To run the  code!!

Create virtual Environment to use Django

python -m venv venv 
venv\Scripts\activate

Virtual enironment is creaed


Now, to install the necessary extensions

pip install requirements.txt


Then execute the code

Create a user to validate the authentication using username and password

python manage.py createsuperuser


Run the Code and open the website link

python manage.py runserver

Now click the link to enter my website:)





