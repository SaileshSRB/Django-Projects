from django.apps import AppConfig


class WallpaperConfig(AppConfig):
    name = 'wallpaper'
