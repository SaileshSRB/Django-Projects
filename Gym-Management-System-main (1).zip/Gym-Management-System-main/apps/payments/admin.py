from django.contrib import admin
from .models import Payments

admin.site.register(Payments)
